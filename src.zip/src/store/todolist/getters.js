export function myGetter(state) {
    return state.todos.length;
}

export function todos(state) {
    return state.todos;
}