export default function () {
    return {
        todos: [
            {id : 1, name : 'First', completed : false}
        ]
    }
}