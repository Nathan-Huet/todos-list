export default function () {
    return {
        properties: null
    }
}