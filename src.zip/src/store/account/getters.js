export function myGetter(state) {
    return state.properties.length;
}